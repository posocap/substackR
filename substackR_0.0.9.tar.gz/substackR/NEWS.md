# substackR 0.0.9

* Initial CRAN submission.
